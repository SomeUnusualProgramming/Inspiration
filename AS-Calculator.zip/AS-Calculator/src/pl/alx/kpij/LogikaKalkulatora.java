/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.alx.kpij;

/**
 *
 * @author kurs
 */
public class LogikaKalkulatora {
    
    public static double oblicz(double arg1, double arg2, String operacja){
        switch (operacja) {
           case "+":
               return arg1+arg2;
           case "-":
               return arg1-arg2;
           case "/":
               return arg1/arg2;
           case "*":
               return arg1*arg2;
           default:
               return 0.0;
       }
        
        // return 0.0;
    }
    
}
