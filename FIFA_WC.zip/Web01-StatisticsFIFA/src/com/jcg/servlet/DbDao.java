package com.jcg.servlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DbDao {

	static ResultSet rsObj = null;
	static Statement stmtObj = null;
	static Connection connObj = null;

	/***** Method #1 :: This Method Is Used To Create A Connection With The Database *****/
	private static Connection connectDb() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connObj = DriverManager.getConnection("jdbc:mysql://localhost:3306/fifa_wc?autoReconnect=true&useSSL=false", "root", "Adamek_91");			
		} catch (Exception exObj) {
			exObj.printStackTrace();
		}
		return connObj;
	}

	/***** Method #2 :: This Method Is Used To Retrieve The Records From The Database *****/
	public static ResultSet getEmployeeList() {				
		try {
			stmtObj = connectDb().createStatement();

			String sql = "SELECT winner, count(winner) FROM `fifa_wc`.`world-cup` WHERE  `ROUND` LIKE 'FINAL' group by `winner` order by `winner`";
			rsObj = stmtObj.executeQuery(sql);
		} catch (Exception exObj) {
			exObj.printStackTrace();
		}
		return rsObj;
	}

	/***** Method #3 :: This Method Is Used To Close The Connection With The Database *****/
	public static void disconnectDb() {
		try {
			rsObj.close();
			stmtObj.close();
			connObj.close();
		} catch (Exception exObj) {
			exObj.printStackTrace();
		}		
	}
}
