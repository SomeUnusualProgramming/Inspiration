package main;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.net.ssl.HostnameVerifier;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.plaf.basic.BasicToolBarUI.DockingListener;

import com.mysql.fabric.Response;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

/**
 * Servlet implementation class Program
 */
@WebServlet("/Program")
public class Program extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
			        handleRequest(request, response);
			    }

	
	public void handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		response.setContentType("text/html");
		response.setCharacterEncoding("utf-8");

		PrintWriter out = response.getWriter();

		String title = "Employee Details";

		String pageTitle = "Servlet Database Connectivity Example";

		String docType = "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n";

		out.println(docType + "<html>\n" + "<head><title>" + pageTitle + "</title></head>\n");

		try (Connection c = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/fifa_wc?autoReconnect=true&useSSL=false", "root", "Adamek_91")) {

			try (Statement stmt = c.createStatement();
					ResultSet rs = stmt.executeQuery(
							"SELECT winner, count(winner) FROM `fifa_wc`.`world-cup` WHERE  `ROUND` LIKE 'FINAL' group by `winner` order by `winner`")) {

				if(rs.next()) {
						                out.println("<body>\n" + "<h2 align = \"center\" style = \"color: green;\">" + title + "</h2>\n" + 
						                        "<table width = \"450px\" border = \"1\" align = \"center\">\n" + 
						                        "<thead><tr align = \"center\"><th><strong>Emp. Id</strong></th><th><strong>Emp. Name</strong></th><th><strong>Emp. Salary (in '$')</strong></th></tr></thead>\n<tbody>");
						 
						                do {
						                    out.println("<tr align = \"center\"><td>" + rs.getString("emp_id") + "</td><td>" + rs.getString("emp_name") + "</td><td>" + rs.getString("emp_salary") + "</td></tr>");
						                } while (rs.next());
						                 out.println("</tbody>\n</table></body></html>");
						                } else {
							                out.println("<body>\n" + "<h2 align = \"center\" style = \"color: red;\">No Employees Found In The Db....!</h2>\n" + "</body>");
							            }
						                
						                out.println("</html>");
						                	            out.close();
						                	        } catch(Exception exObj) {
						                	            exObj.printStackTrace();
						                	        } finally {
						                	        	
						                	        }
						                	    } catch (SQLException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
												}
						                	}
	}
