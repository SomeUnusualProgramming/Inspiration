package main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.net.ssl.HostnameVerifier;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.plaf.basic.BasicToolBarUI.DockingListener;

import com.mysql.fabric.Response;

public class Run {
	
	
	public static void main(String[] args) {
		
		try (Connection c = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/fifa_wc?autoReconnect=true&useSSL=false", "root", "XXXXXX")) {

			try (Statement stmt = c.createStatement();
					ResultSet rs = stmt.executeQuery(
							"SELECT winner, count(winner) FROM `fifa_wc`.`world-cup` WHERE  `ROUND` LIKE 'FINAL' group by `winner` order by `winner`")) { 

				while (rs.next()) {

					Winners.setHomeTeam(rs.getString(1));
					Winners.setWins(rs.getInt(2));

					System.out.println(Winners.getHomeTeam() + " " + Winners.getWins());
					

				}
				
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}