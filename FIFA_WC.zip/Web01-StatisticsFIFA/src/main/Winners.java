package main;

public class Winners {

	public static String homeTeam;
	public static int Wins;
	
	public Winners() {
		
	}
	
	public Winners(String homeTeam, int Wins) {
		
	}
	
	public static String getHomeTeam() {
		return homeTeam;
	}

	public static void setHomeTeam(String homeTeam) {
		Winners.homeTeam = homeTeam;
	}

	public static int getWins() {
		return Wins;
	}

	public static void setWins(int Wins) {
		Winners.Wins = Wins;
	}

	
	
	
	
}
